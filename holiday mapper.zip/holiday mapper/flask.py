from flask import Flask
from datetime import date
import holidays

# Create a Flask web server instance
app = Flask(__name__)

# Define a route for the home page
@app.route("/")
def is_holiday():
    today = date.today()
    # Create a holidays instance for the United States
    us_holidays = holidays.US()

    # Check if today is a holiday
    if today in us_holidays:
        holiday_name = us_holidays.get(today)
        return f"<h1>Today is {today.strftime('%B %d, %Y')}. It is a holiday: {holiday_name}!</h1>"
    else:
        return f"<h1>Today is {today.strftime('%B %d, %Y')}. Not a holiday.</h1>"

if __name__ == "__main__":
    app.run(debug=True)
