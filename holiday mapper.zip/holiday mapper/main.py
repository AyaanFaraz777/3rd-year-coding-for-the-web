from flask import Flask, render_template, request
import holidays
from datetime import date

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/check_holiday', methods=['POST'])
def check_holiday():
    country_code = request.form['country'].upper()
    year = int(request.form['year'])

    try:
        # Get holidays for the specified country and year
        country_holidays = holidays.CountryHoliday(country_code, years=year)
        
        # Format holidays for display
        holiday_list = []
        for holiday_date, holiday_name in sorted(country_holidays.items()):
            holiday_list.append(f"{holiday_date}: {holiday_name}")

        return render_template('results.html', country=country_code, year=year, holidays=holiday_list)
    except Exception as e:
        return render_template('error.html', message=f"Error: {e}. Please check the country code.")

if __name__ == '__main__':
    app.run(debug=True)
