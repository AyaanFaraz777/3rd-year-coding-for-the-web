import holidays
from datetime import date

# Option 1: Unpack into two variables (consistent with second loop)
for day, name in sorted(holidays.India(years=2004).items()):
    print(day, name)

print("----------------------")

for day, name in sorted(holidays.India(years=2004, state="KL").items()):
    print(day, name)
    print("----------------------")


